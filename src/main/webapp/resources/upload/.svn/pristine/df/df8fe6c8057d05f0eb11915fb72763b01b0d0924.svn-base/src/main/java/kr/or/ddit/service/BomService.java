package kr.or.ddit.service;

import java.util.List;

import kr.or.ddit.vo.BomVO;

public interface BomService {
	//메소드 시그니처
	public List<BomVO> list();
	
}
