package kr.or.ddit.mapper;

import java.util.List;

import kr.or.ddit.vo.BomVO;

public interface BomMapper {
	//BOM 테이블 목록
	public List<BomVO> list();
}
